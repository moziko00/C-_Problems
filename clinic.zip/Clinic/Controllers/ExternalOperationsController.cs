﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Clinic.Data;
using Clinic.Models;

namespace Clinic.Controllers
{
    public class ExternalOperationsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ExternalOperationsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: ExternalOperations
        public async Task<IActionResult> Index()
        {
            return View(await _context.ExternalOperations.ToListAsync());
        }

        // GET: ExternalOperations/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var externalOperations = await _context.ExternalOperations
                .FirstOrDefaultAsync(m => m.ExternalOperationsId == id);
            if (externalOperations == null)
            {
                return NotFound();
            }

            return View(externalOperations);
        }

        // GET: ExternalOperations/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: ExternalOperations/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ExternalOperationsId,ExternalOperationsName")] ExternalOperations externalOperations)
        {
            if (ModelState.IsValid)
            {
                _context.Add(externalOperations);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(externalOperations);
        }

        // GET: ExternalOperations/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var externalOperations = await _context.ExternalOperations.FindAsync(id);
            if (externalOperations == null)
            {
                return NotFound();
            }
            return View(externalOperations);
        }

        // POST: ExternalOperations/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ExternalOperationsId,ExternalOperationsName")] ExternalOperations externalOperations)
        {
            if (id != externalOperations.ExternalOperationsId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(externalOperations);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!ExternalOperationsExists(externalOperations.ExternalOperationsId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(externalOperations);
        }

        // GET: ExternalOperations/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var externalOperations = await _context.ExternalOperations
                .FirstOrDefaultAsync(m => m.ExternalOperationsId == id);
            if (externalOperations == null)
            {
                return NotFound();
            }

            return View(externalOperations);
        }

        // POST: ExternalOperations/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var externalOperations = await _context.ExternalOperations.FindAsync(id);
            if (externalOperations != null)
            {
                _context.ExternalOperations.Remove(externalOperations);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool ExternalOperationsExists(int id)
        {
            return _context.ExternalOperations.Any(e => e.ExternalOperationsId == id);
        }
    }
}
