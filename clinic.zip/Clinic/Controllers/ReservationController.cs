﻿using Clinic.Data;
using Clinic.Models;
using Clinic.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Internal;

namespace Clinic.Controllers
{
    public class ReservationController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ReservationController(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index()
        {
            var reservations = await _context.Reservations
                .Include(r => r.Employee)
                .Include(r => r.ClinicReservation)
                    .ThenInclude(cr => cr.Clinic)
                .Include(r => r.ConvoysReservation)
                    .ThenInclude(cv => cv.MedicalConvoys)
                .ToListAsync();
            Console.WriteLine($"User: {User.Identity?.Name}");
            return View(reservations);
        }
        
        public async Task<IActionResult> Create(int uniqueEmployeeId)
        {
            // Find the employee by UniqueEmployeeId
            var employee = await _context.Employees
                .FirstOrDefaultAsync(e => e.UniqueEmployeeId == uniqueEmployeeId);

            if (employee == null)
            {
                // Handle the case when the employee is not found
                return NotFound("Employee not found.");
            }

            // Load clinics and medical convoys to display in the form
            var clinics = await _context.Clinics.ToListAsync();
            var medicalConvoys = await _context.MedicalConvoys.ToListAsync();

            ViewBag.EmployeeName = employee.EmployeeName; // Pass employee name to the view
            ViewBag.Clinics = clinics;
            ViewBag.MedicalConvoys = medicalConvoys;

            return View();
        }

        // POST: Reservations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Reservation reservation, int? selectedClinicId, int? selectedConvoyId)
        {
            //if (ModelState.IsValid)
            //{
            // Generate TicketNum (implement your logic here)
            reservation.TicketNum = await GetNextTicketNumAsync();
            reservation.ResDate = DateTime.Now;

            // Add the reservation to the context
            //_context.Reservations.Add(reservation);
            //await _context.SaveChangesAsync();


            // Create the ClinicReservation if a clinic is selected
            if (selectedClinicId.HasValue)
            {
                var clinicReservation = new ClinicReservation
                {
                    ClinicId = selectedClinicId.Value
                    //,
                    //ReservationId = reservation.ReservationId
                };
                _context.Reservations.Add(new Reservation
                {
                    ClinicReservation = clinicReservation,
                    EmployeeId = 5,
                    ResDate = DateTime.Now,
                    TicketNum = 11,

                });
                //_context.ClinicReservations.Add(clinicReservation);
            }

            // Create the ConvoysReservation if a convoy is selected
            if (selectedConvoyId.HasValue)
            {

                var convoysReservation = new ConvoysReservation
                {
                    MedicalConvoysId = selectedConvoyId.Value
                    //,
                    //ReservationId = reservation.ReservationId
                };
                _context.Reservations.Add(new Reservation
                {
                    ConvoysReservation = convoysReservation,
                    EmployeeId = 5,
                    ResDate = DateTime.Now,
                    TicketNum = 11,

                });
            }

            // Save the related entities
            await _context.SaveChangesAsync();

            return RedirectToAction("Index"); // Redirect to a suitable action
            //}

            // Reload clinics and employees if model state is invalid
            var clinics = await _context.Clinics.ToListAsync();
            var employees = await _context.Employees.ToListAsync();
            var medicalConvoys = await _context.MedicalConvoys.ToListAsync();
            ViewBag.Clinics = clinics;
            ViewBag.Employees = employees;
            ViewBag.MedicalConvoys = medicalConvoys;

            return View(reservation);
        }
        #region TestCreate
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(string reservationType, int? selectedClinicId, int? selectedConvoyId, int employeeId)
        {
            if (ModelState.IsValid)
            {
                var reservation = new Reservation
                {
                    EmployeeId = employeeId, // Set the employee ID
                    TicketNum = await GetNextTicketNumAsync(),
                    ResDate = DateTime.Now,
                };

                _context.Reservations.Add(reservation);
                await _context.SaveChangesAsync();

                if (reservationType == "clinic" && selectedClinicId.HasValue)
                {
                    var clinicReservation = new ClinicReservation
                    {
                        ClinicId = selectedClinicId.Value,
                        ReservationId = reservation.ReservationId
                    };
                    _context.ClinicReservations.Add(clinicReservation);
                }
                else if (reservationType == "convoy" && selectedConvoyId.HasValue)
                {
                    var convoysReservation = new ConvoysReservation
                    {
                        MedicalConvoysId = selectedConvoyId.Value,
                        ReservationId = reservation.ReservationId
                    };
                    _context.convoysReservations.Add(convoysReservation);
                }

                await _context.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            // Reload data if the model state is invalid
            var clinics = await _context.Clinics.ToListAsync();
            var medicalConvoys = await _context.MedicalConvoys.ToListAsync();
            ViewBag.Clinics = clinics;
            ViewBag.MedicalConvoys = medicalConvoys;

            return View();
        }

        #endregion

        private async Task<int> GetNextTicketNumAsync()
        {
            // Implement your logic to get the next ticket number
            // For example, you could use the max existing ticket number + 1
            return (await _context.Reservations.MaxAsync(r => (int?)r.TicketNum)) ?? 1;
        }
    }
}
