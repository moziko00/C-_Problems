﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Clinic.Data;
using Clinic.Models;

namespace Clinic.Controllers
{
    public class AllergensController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AllergensController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Allergens
        public async Task<IActionResult> Index()
        {
            return View(await _context.Allergens.ToListAsync());
        }

        // GET: Allergens/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var allergens = await _context.Allergens
                .FirstOrDefaultAsync(m => m.AllergensId == id);
            if (allergens == null)
            {
                return NotFound();
            }

            return View(allergens);
        }

        // GET: Allergens/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Allergens/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("AllergensId,AllergensName")] Allergens allergens)
        {
            if (ModelState.IsValid)
            {
                _context.Add(allergens);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(allergens);
        }

        // GET: Allergens/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var allergens = await _context.Allergens.FindAsync(id);
            if (allergens == null)
            {
                return NotFound();
            }
            return View(allergens);
        }

        // POST: Allergens/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("AllergensId,AllergensName")] Allergens allergens)
        {
            if (id != allergens.AllergensId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(allergens);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AllergensExists(allergens.AllergensId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(allergens);
        }

        // GET: Allergens/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var allergens = await _context.Allergens
                .FirstOrDefaultAsync(m => m.AllergensId == id);
            if (allergens == null)
            {
                return NotFound();
            }

            return View(allergens);
        }

        // POST: Allergens/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var allergens = await _context.Allergens.FindAsync(id);
            if (allergens != null)
            {
                _context.Allergens.Remove(allergens);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AllergensExists(int id)
        {
            return _context.Allergens.Any(e => e.AllergensId == id);
        }
    }
}
