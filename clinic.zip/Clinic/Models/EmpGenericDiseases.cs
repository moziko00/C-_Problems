﻿namespace Clinic.Models
{
    public class EmpGenericDiseases
    {
        public int EmpGenericDiseasesId { get; set; }
        public int EmployeeId { get; set; }
        public int GenericDiseasesId { get; set; }

        public Employee Employee { get; set; }
        public GenericDiseases GenericDisease { get; set; }
    }
}
