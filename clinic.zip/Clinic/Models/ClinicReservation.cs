﻿namespace Clinic.Models
{
    public class ClinicReservation
    {
        public int ClinicReservationId { get; set; }
        public int ReservationId { get; set; }
        public  Reservation Reservation { get; set; }
        public int ClinicId { get; set; }
        public  Clinic Clinic { get; set; }
    }
}
