﻿namespace Clinic.Models
{
    public class MedicalConvoys
    {
        public int MedicalConvoysId { get; set; }
        public string ConvoysName { get; set; }
        public string ConvoysProvider { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        public string Description { get; set; }
        public int SectorId { get; set; }
        public Sector Sector { get; set; }
        //public int ConvoysResId { get; set; }
        //public ConvoysReservation ConvoysReservation { get; set; }
    }
}
