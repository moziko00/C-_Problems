﻿namespace Clinic.Models
{
    public class ChronicDiseases
    {
        public int ChronicDiseasesId { get; set; }
        public string ChronicDiseasesName { get; set; }
        public ICollection<EmpChronicDiseases>? EmpChronicDiseases { get; set; }
    }
}
