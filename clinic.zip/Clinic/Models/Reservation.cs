﻿namespace Clinic.Models
{
    public class Reservation
    {
        public int ReservationId { get; set; }
        public DateTime ResDate { get; set; }=DateTime.Now;
        public int TicketNum { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
        
        public ClinicReservation? ClinicReservation { get; set; }
        public int ClinicReservationId { get; set; }
        public ConvoysReservation? ConvoysReservation { get; set; }
        public int ConvoysReservationId { get; set; }


    }
}
