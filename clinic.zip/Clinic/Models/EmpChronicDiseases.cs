﻿namespace Clinic.Models
{
    public class EmpChronicDiseases
    {
        public int EmpChronicDiseasesId { get; set; }
        public int ChronicDiseasesId { get; set; }
        public ChronicDiseases ChronicDiseases { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
