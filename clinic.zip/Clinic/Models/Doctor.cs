﻿namespace Clinic.Models
{
    public class Doctor
    {
        public int DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string PhoneNumber { get; set; }
        public int ClinicId { get; set; }
        public Clinic Clinic { get; set; }
        public string Status { get; set; }

    }
}
