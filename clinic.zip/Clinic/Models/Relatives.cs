﻿namespace Clinic.Models
{
    public class Relatives
    {
        public int RelativesId { get; set; }
        public string RelativeName { get; set; }

    }
}
