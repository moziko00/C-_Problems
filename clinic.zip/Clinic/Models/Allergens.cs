﻿namespace Clinic.Models
{
    public class Allergens
    {
        public int AllergensId { get; set; }
        public string AllergensName { get; set; }
        public ICollection<EmpAllergens> EmpAllergens { get; set; }
    }
}
