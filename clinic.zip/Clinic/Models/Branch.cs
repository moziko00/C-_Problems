﻿namespace Clinic.Models
{
    public class Branch
    {
        public int BranchId { get; set; }
        public string BranchName { get; set; }
        public ICollection<Employee> Employee { get; set; }
    }
}
