﻿namespace Clinic.Models
{
    public class ExternalOperations
    {
        public int ExternalOperationsId { get; set; }
        public string ExternalOperationsName { get; set; }
        public ICollection<EmpExternalOperations> EmpExternalOperations { get; set; }
    }
}
