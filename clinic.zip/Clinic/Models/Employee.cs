﻿using System.Reflection.Metadata;

namespace Clinic.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string EmployeeName { get; set; }
        public int UniqueEmployeeId { get; set; }
        public int MedicalInsuranceid { get; set; }
        public string PhoneNumber { get; set; }
        public string Email { get; set; }
        public string NationalId { get; set; }
        public string Image { get; set; }
        public string ImageMimeType { get; set; }
        public string ImageFileName { get; set; }
        public int RegionId { get; set; }
        public Region Region { get; set; }
        public int BranchId { get; set; }
        public Branch Branch { get; set; }
        public int SectorId { get; set; }
        public Sector Sector { get; set; }
        public ICollection<EmpGenericDiseases> EmpGenericDiseases { get; set; }
        public ICollection<EmpChronicDiseases> EmpChronicDiseases { get; set; }
        public ICollection<EmpAllergens> EmpAllergens { get; set; }
        public ICollection <EmpExternalOperations> EmpExternalOperations { get; set; }

    }
}
