﻿namespace Clinic.Models
{
    public class Clinic
    {
        public int ClinicId { get; set; }
        public string ClinicName { get; set; }
        public int SectorId { get; set; }
        public Sector? Sector { get; set; }
        public ICollection<Doctor>? Doctors { get; set; }
        public ICollection<ClinicReservation>? ClinicReservation { get; set; }

    }
}
