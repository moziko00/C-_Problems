﻿namespace Clinic.Models
{
    public class Document
    {
        public int DocumentId { get; set; }
        public string DocumentName { get; set; }
        public int ReservationServiceId { get; set; }
        public ReservationService ReservationService { get; set; }



    }
}
