﻿namespace Clinic.Models
{
    public class EmpExternalOperations
    {
        public int EmpExternalOperationsId { get; set; }
        public int ExternalOperationsId { get; set; }
        public ExternalOperations ExternalOperations { get; set; }
        public DateTime Date { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }
    }
}
