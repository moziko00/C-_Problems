﻿namespace Clinic.Models
{
    public class Sector
    {
        public int SectorId { get; set; }
        public string SectorName { get; set; }
        public ICollection<Clinic>? Clinic { get; set; }
        public ICollection<Employee>? Employee { get; set; }

    }
}
