﻿namespace Clinic.Models.ViewModels
{
    public class ReservationViewModel
    {
        public DateTime ResDate { get; set; }
        public int TicketNum { get; set; }
        public int EmployeeId { get; set; }
        public List<int> ClinicIds { get; set; } = new List<int>();

    }
}
