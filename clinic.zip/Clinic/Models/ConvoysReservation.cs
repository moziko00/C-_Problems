﻿namespace Clinic.Models
{
    public class ConvoysReservation
    {
        public int ConvoysReservationId { get; set; }
        public int ReservationId { get; set; }
        public Reservation Reservation { get; set; }
        public int MedicalConvoysId { get; set; }
        public MedicalConvoys MedicalConvoys { get; set; }

    }
}
