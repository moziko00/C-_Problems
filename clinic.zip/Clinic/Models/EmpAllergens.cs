﻿namespace Clinic.Models
{
    public class EmpAllergens
    {
        public int EmpAllergensId { get; set; }
        public int AllergensId { get; set; }
        public Allergens Allergens { get; set; }
        public int EmployeeId { get; set; }
        public Employee Employee { get; set; }

    }
}
