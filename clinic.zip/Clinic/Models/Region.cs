﻿namespace Clinic.Models
{
    public class Region
    {
        public int RegionId { get; set; }
        public string RegionName { get; set; }
        public ICollection <Employee> Employee { get; set; }
    }
}
