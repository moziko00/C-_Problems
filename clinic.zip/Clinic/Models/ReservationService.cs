﻿namespace Clinic.Models
{
    public class ReservationService
    {
        public int ReservationServiceId { get; set; }
        public string Description { get; set; }
        public int ReservationId { get; set; }
        public int ServiceId { get; set; }
        public Service Service { get; set; }
        public Reservation Reservation { get; set; }
        public ICollection<Document> Documents { get; set; }
    }
}
