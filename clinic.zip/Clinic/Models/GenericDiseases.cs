﻿namespace Clinic.Models
{
    public class GenericDiseases
    {
        public int GenericDiseasesId { get; set; }
        public string GenericDiseaseName { get; set; }
        public string RelativeId { get; set; }
        public Relatives Relative { get; set; }
        public ICollection<EmpGenericDiseases> EmpGenericDiseases { get; set; }
    }
}
