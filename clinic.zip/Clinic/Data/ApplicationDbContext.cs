﻿using Clinic.Models;
using Microsoft.EntityFrameworkCore;
using System.Drawing;

namespace Clinic.Data
{
    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {

        }
        public DbSet<AdditionalServices> AdditionalServices { get; set; }
        public DbSet<Allergens> Allergens { get; set; }
        public DbSet<Branch> Branches { get; set; }
        public DbSet<ChronicDiseases> ChronicDiseases { get; set; }

        public DbSet<Employee> Employees { get; set; }
        public DbSet<ClinicReservation> ClinicReservations { get; set; }

        public DbSet<ConvoysReservation> convoysReservations { get; set; }
        public DbSet<Doctor> Doctors { get; set; }

        public DbSet<Document> Documents { get; set; }

        public DbSet<EmpAllergens> EmpAllergens { get; set; }
        public DbSet<EmpChronicDiseases> EmpChronicDiseases { get; set; }

        public DbSet<EmpExternalOperations> EmpExternalOperations { get; set; }

        public DbSet<EmpGenericDiseases> EmpGenericDiseases { get; set; }

        public DbSet<ExternalOperations> ExternalOperations { get; set; }
        public DbSet<GenericDiseases> GenericDiseases { get; set; }

        public DbSet<MedicalConvoys> MedicalConvoys { get; set; }

        public DbSet<Models.Region> Regions { get; set; }
        public DbSet<Relatives> Relatives { get; set; }

        public DbSet<Reservation> Reservations { get; set; }

        public DbSet<ReservationService> ReservationServices { get; set; }
        public DbSet<Sector> Sectors { get; set; }

        public DbSet<Service> Services { get; set; }
        public DbSet<Models.Clinic> Clinics { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // One-to-One relationship between Reservation and ClinicReservation
            modelBuilder.Entity<ClinicReservation>()
                .HasKey(cr => cr.ClinicReservationId);

            modelBuilder.Entity<ClinicReservation>()
                .HasOne(cr => cr.Reservation)
                .WithOne(r => r.ClinicReservation)
                .HasForeignKey<ClinicReservation>(cr => cr.ReservationId)
                .OnDelete(DeleteBehavior.Restrict); // Change to Restrict

            // One-to-One relationship between Reservation and ConvoysReservation
            modelBuilder.Entity<ConvoysReservation>()
                .HasKey(cvr => cvr.ConvoysReservationId);

            modelBuilder.Entity<ConvoysReservation>()
                .HasOne(cvr => cvr.Reservation)
                .WithOne(r => r.ConvoysReservation)
                .HasForeignKey<ConvoysReservation>(cvr => cvr.ReservationId)
                .OnDelete(DeleteBehavior.Restrict); // Change to Restrict
        }

    }
}
